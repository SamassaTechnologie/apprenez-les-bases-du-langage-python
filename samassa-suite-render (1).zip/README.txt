
Samassa Technologie – Suite Documents (Facture, Reçu, Devis, Lettres)

Site statique + PWA, prêt pour hébergement sur Render (Static Site).

Déployer sur Render (Static Site)
1. Crée un dépôt GitHub et envoie ces fichiers.
2. Va sur https://render.com → New → Static Site.
3. Connecte ton dépôt GitHub.
4. Build Command : (laisser vide)
5. Publish Directory : /
6. Create Static Site.

Conseils
- Pour activer le mode hors‑ligne, ouvre l’URL une première fois.
- Pour mettre à jour, pousse sur GitHub et Render redéploie.
